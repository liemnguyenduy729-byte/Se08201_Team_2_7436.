# StudyAI Mentor Người 3

Bài trắc nghiệm có chấm điểm và thẻ ghi nhớ.

Mở một lời giải để tạo bài trắc nghiệm và lưu thành thẻ. Xem thẻ offline tại Trang chủ > Thẻ ghi nhớ. Tạo đề mới cần ViLao và Internet.

Giải nén, mở thư mục chứa settings.gradle.kts trong Android Studio, dùng SDK 37 và chạy cấu hình app. Bản demo dùng mã ứng dụng riêng và tài khoản cục bộ riêng.

Gói gồm phiên bản chung trước nâng cấp và hai chức năng mới của thành viên. Khi hợp nhất vào dự án nhóm, dùng các chức năng từ MainActivity.kt đã tích hợp trong dự án chính. Không ghi đè toàn bộ MainActivity.kt bằng bản riêng.

Trong Thẻ ghi nhớ, mở đáp án của thẻ đến hạn rồi chọn Chưa nhớ hoặc Đã nhớ. Thẻ chưa nhớ được ôn lại ngày mai. Các lần nhớ liên tiếp tăng khoảng cách lên 1, 3, 7, 14 và 30 ngày. Lịch lưu theo tài khoản và hoạt động offline.
