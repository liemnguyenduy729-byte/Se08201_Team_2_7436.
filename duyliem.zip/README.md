# StudyAI Mentor — Người 3

Giải nén và mở thư mục trong Android Studio với Android SDK 37. Chọn cấu hình app và bấm Run. App có ID riêng và cài song song được với bản nhóm.

- Tìm, lọc theo môn và mở lại các mục trong Lịch sử học tập.
- Mở bài Toán có sẵn để thử xem lời giải và bật/tắt đáp án bài ôn khi offline.
- Vào Nhắc học để chọn, đổi hoặc tắt giờ nhắc hằng ngày. Cho phép thông báo khi Android hỏi. Hệ điều hành có thể phát thông báo muộn hơn giờ đã đặt.

Bản demo dùng hai lời giải mẫu lưu cục bộ. Khi gộp với dự án nhóm, bỏ seedDemo và dùng mã tài khoản thật. Dùng chung khóa history:<id tài khoản> và review:<id tài khoản>:<id lời giải> với Người 2. Chuyển các màn hình lịch sử và xem lại bài ôn từ MainActivity.kt, lớp StudyReminderReceiver.kt, receiver và hai quyền thông báo/khởi động trong manifest. Bản demo không yêu cầu khóa API.
