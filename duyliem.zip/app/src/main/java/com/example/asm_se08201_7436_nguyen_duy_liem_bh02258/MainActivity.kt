package com.example.asm_se08201_7436_nguyen_duy_liem_bh02258

import android.app.Activity
import android.app.AlertDialog
import android.app.NotificationManager
import android.app.TimePickerDialog
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.text.InputType
import android.view.Gravity
import android.view.View
import android.view.WindowInsets
import android.widget.*
import org.json.JSONArray
import org.json.JSONObject
import java.text.DateFormat
import java.util.Calendar
import java.util.Date

class MainActivity : Activity() {
    private val ink = Color.rgb(13, 24, 57)
    private val muted = Color.rgb(65, 83, 128)
    private val blue = Color.rgb(28, 86, 240)
    private val paper = Color.rgb(246, 248, 255)
    private val tint = Color.rgb(232, 238, 254)
    private val white = Color.WHITE

    private enum class Screen { HISTORY, RESULT, REMINDERS }
    private lateinit var root: LinearLayout
    private lateinit var page: LinearLayout
    private var screen = Screen.HISTORY
    private val owner = "demo"
    private var resultId = -1L
    private var historySubject = -1
    private var query = ""
    private val prefs by lazy { getSharedPreferences("study_mentor", MODE_PRIVATE) }
    private val reminders by lazy { StudyReminders(this) }
    private val subjects = listOf("Toán", "Vật lý", "Hóa học", "Sinh học", "Ngữ văn", "Tiếng Anh", "Lập trình", "Khác")
    private val symbols = listOf("π", "⚛", "⚗", "❧", "▤", "Ⓐ", "⌘", "⋯")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.decorView.systemUiVisibility = View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR or View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR
        window.statusBarColor = paper
        window.navigationBarColor = paper
        seedDemo()
        show(Screen.HISTORY)
    }

    @Deprecated("Back navigation is handled by the Activity")
    override fun onBackPressed() {
        if (screen == Screen.HISTORY) super.onBackPressed() else back()
    }

    private fun back() = show(Screen.HISTORY)
    private fun dp(n: Int) = (n * resources.displayMetrics.density + .5f).toInt()
    private fun shape(color: Int, radius: Int = 20) = GradientDrawable().apply {
        setColor(color)
        cornerRadius = dp(radius).toFloat()
    }

    private fun gradient(start: Int, end: Int, radius: Int = 24) =
        GradientDrawable(GradientDrawable.Orientation.TL_BR, intArrayOf(start, end)).apply {
            cornerRadius = dp(radius).toFloat()
        }

    private fun column() = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
    private fun row() = LinearLayout(this).apply {
        gravity = Gravity.CENTER_VERTICAL
        isBaselineAligned = false
    }
    private fun LinearLayout.add(view: View, gap: Int = 0, height: Int = -2) {
        addView(view, LinearLayout.LayoutParams(-1, if (height < 0) height else dp(height)).apply {
            topMargin = dp(gap)
        })
    }

    private fun LinearLayout.equal(view: View, gap: Int = 0) {
        addView(view, LinearLayout.LayoutParams(0, -2, 1f).apply { marginStart = dp(gap) })
    }

    private fun View.inset(horizontal: Int, vertical: Int) =
        setPadding(dp(horizontal), dp(vertical), dp(horizontal), dp(vertical))

    private fun label(value: CharSequence, size: Int = 16, color: Int = ink, bold: Boolean = false) =
        TextView(this).apply {
            text = value
            textSize = size.toFloat()
            setTextColor(color)
            if (bold) typeface = Typeface.DEFAULT_BOLD
        }

    private fun action(value: String, active: Boolean = true, run: () -> Unit) =
        label(value, 15, if (active) white else blue, true).apply {
            gravity = Gravity.CENTER
            minHeight = dp(48)
            inset(12, 10)
            background = if (active) gradient(0xff397cfa.toInt(), blue, 18) else shape(tint, 16)
            setOnClickListener { run() }
        }

    private fun card(color: Int = white) = column().apply {
        background = shape(color, 20)
        inset(16, 14)
        elevation = dp(2).toFloat()
    }

    private fun title(value: String, backButton: Boolean = true) {
        val bar = row()
        val heading = label(value, 21, bold = true).apply { gravity = Gravity.CENTER }
        if (backButton) bar.addView(label("‹", 32, bold = true).apply {
            gravity = Gravity.CENTER
            contentDescription = "Quay lại"
            setOnClickListener { back() }
        }, dp(44), dp(48))
        bar.addView(heading, LinearLayout.LayoutParams(0, dp(52), 1f))
        if (backButton) bar.addView(View(this), dp(44), dp(48))
        page.add(bar)
    }

    private fun show(destination: Screen) {
        screen = destination
        root = column().apply { setBackgroundColor(paper) }
        root.setOnApplyWindowInsetsListener { view, insets ->
            if (android.os.Build.VERSION.SDK_INT >= 30) {
                val padding = insets.getInsets(WindowInsets.Type.systemBars() or WindowInsets.Type.displayCutout() or WindowInsets.Type.ime())
                view.setPadding(padding.left, padding.top, padding.right, padding.bottom)
            }
            insets
        }
        if (android.os.Build.VERSION.SDK_INT < 30) root.fitsSystemWindows = true
        page = column().apply {
            setPadding(dp(20), dp(8), dp(20), dp(24))
            isFocusableInTouchMode = true
        }
        val scroll = ScrollView(this).apply {
            isFillViewport = true
            clipToPadding = false
            addView(page)
        }
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        setContentView(root)
        when (destination) {
            Screen.HISTORY -> history()
            Screen.RESULT -> result()
            Screen.REMINDERS -> reminderScreen()
        }
        if (destination != Screen.RESULT) {
            val navigation = row().apply { inset(8, 8) }
            navigation.equal(action("Lịch sử", destination == Screen.HISTORY) { show(Screen.HISTORY) })
            navigation.equal(action("Nhắc học", destination == Screen.REMINDERS) { show(Screen.REMINDERS) }, 8)
            root.add(navigation)
        }
    }
    private fun centered(value: String, size: Int, color: Int = ink, bold: Boolean = false) =
        label(value, size, color, bold).apply { gravity = Gravity.CENTER }

    private fun listItem(icon: String, name: String, detail: String, run: () -> Unit): View = row().apply {
        background = shape(white, 18)
        elevation = dp(2).toFloat()
        inset(14, 12)
        addView(centered(icon, 22, blue, true).apply { background = shape(tint, 12) }, dp(44), dp(44))
        addView(column().apply {
            add(label(name, 16, bold = true))
            if (detail.isNotEmpty()) add(label(detail, 13, muted), 3)
        }, LinearLayout.LayoutParams(0, -2, 1f).apply { marginStart = dp(12); marginEnd = dp(8) })
        addView(label("›", 22, blue, true))
        setOnClickListener { run() }
    }

    private fun input(hintText: String, initial: String = "", multiline: Boolean = false) =
        EditText(this).apply {
            hint = hintText
            setText(initial)
            setTextColor(ink)
            setHintTextColor(muted)
            textSize = 15f
            inputType = InputType.TYPE_CLASS_TEXT or if (multiline) InputType.TYPE_TEXT_FLAG_MULTI_LINE else 0
            gravity = if (multiline) Gravity.TOP else Gravity.CENTER_VERTICAL
            background = shape(tint, 16)
            inset(14, 12)
        }

    private fun historyFor() = JSONArray(prefs.getString("history:$owner", "[]"))

    private fun seedDemo() {
        if (prefs.contains("history:$owner")) return
        val first = System.currentTimeMillis()
        val history = JSONArray()
            .put(JSONObject().put("id", first).put("subject", 0)
                .put("question", "Giải phương trình x² − 5x + 6 = 0")
                .put("answer", "Bước 1. Phân tích thành (x − 2)(x − 3) = 0.\nBước 2. Cho từng thừa số bằng 0.\nKết luận: x = 2 hoặc x = 3."))
            .put(JSONObject().put("id", first + 1).put("subject", 6)
                .put("question", "Vòng lặp for dùng để làm gì?")
                .put("answer", "Dùng for để lặp qua từng phần tử. Ví dụ, for có thể duyệt từng số trong một danh sách để tính tổng."))
        val review = JSONArray()
            .put(JSONObject().put("question", "Hai thừa số của đa thức là gì?").put("answer", "(x − 2) và (x − 3)."))
            .put(JSONObject().put("question", "Khi tích bằng 0, ta xét điều gì?").put("answer", "Ít nhất một thừa số bằng 0."))
            .put(JSONObject().put("question", "Hai nghiệm của phương trình là gì?").put("answer", "x = 2 và x = 3."))
        prefs.edit().putString("history:$owner", history.toString())
            .putString("review:$owner:$first", review.toString()).apply()
    }
    private fun entries(values: JSONArray) = (0 until values.length()).map { values.getJSONObject(it) }

    private fun openResult(id: Long) {
        resultId = id
        show(Screen.RESULT)
    }

    private fun result() {
        title("Lời giải đã lưu")
        val entry = entries(historyFor()).firstOrNull { it.getLong("id") == resultId } ?: return
        page.add(card(0xffeae0fc.toInt()).apply { add(label(entry.getString("question"), 18, bold = true)) }, 12)
        page.add(card().apply {
            add(label("▤  Lời giải", 19, blue, true))
            add(label(entry.getString("answer"), 16).apply {
                setLineSpacing(dp(4).toFloat(), 1f)
                setTextIsSelectable(true)
            }, 12)
        }, 14)
        prefs.getString("review:$owner:$resultId", null)?.let { showReview(JSONArray(it)) }
    }
    private fun showReview(questions: JSONArray) {
        page.add(label("Bài ôn tập", 20, bold = true), 16)
        entries(questions).forEachIndexed { index, item ->
            page.add(card().apply {
                add(label("${index + 1}. ${item.getString("question")}", 16, bold = true))
                val answer = label(item.getString("answer"), 16).apply {
                    visibility = View.GONE
                    setTextIsSelectable(true)
                }
                lateinit var toggle: TextView
                toggle = action("Hiện đáp án", false) {
                    val visible = answer.visibility == View.VISIBLE
                    answer.visibility = if (visible) View.GONE else View.VISIBLE
                    toggle.text = if (visible) "Hiện đáp án" else "Ẩn đáp án"
                }
                add(toggle, 8)
                add(answer, 8)
            }, 10)
        }
    }

    private fun history() {
        title("Lịch sử học tập", false)
        val search = input("⌕   Tìm theo câu hỏi…", query)
        page.add(search, 8)
        val filters = HorizontalScrollView(this).apply { isHorizontalScrollBarEnabled = false }
        val filterRow = row()
        filters.addView(filterRow)
        val results = column()
        fun update() {
            results.removeAllViews()
            val filtered = entries(historyFor()).asReversed().filter {
                (historySubject < 0 || it.getInt("subject") == historySubject) &&
                    it.getString("question").contains(query.trim(), ignoreCase = true)
            }
            filtered.forEach { entry ->
                val index = entry.getInt("subject")
                val id = entry.getLong("id")
                val date = DateFormat.getDateTimeInstance(DateFormat.SHORT, DateFormat.SHORT).format(Date(id))
                results.add(listItem(symbols[index], entry.getString("question"), "${subjects[index]} · $date") {
                    openResult(id)
                }, 10)
            }
            if (filtered.isEmpty()) results.add(centered(
                if (query.isBlank() && historySubject < 0) {
                    "Bạn chưa có câu hỏi nào."
                } else "Không tìm thấy câu hỏi phù hợp.", 15, muted
            ), 28)
        }
        fun updateFilters() {
            filterRow.removeAllViews()
            (listOf("Tất cả") + subjects).forEachIndexed { index, name ->
                filterRow.addView(action(name, historySubject == index - 1) {
                    historySubject = index - 1
                    updateFilters()
                    update()
                }, LinearLayout.LayoutParams(-2, -2).apply { marginEnd = dp(6) })
            }
        }
        search.addTextChangedListener(object : android.text.TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) = Unit
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
                query = s.toString()
                update()
            }
            override fun afterTextChanged(s: android.text.Editable?) = Unit
        })
        page.add(filters, 10)
        page.add(results, 6)
        updateFilters()
        update()
    }

    private fun reminderScreen() {
        title("Nhắc lịch học", false)
        val time = reminders.time(owner)
        val schedule = if (time == null) "Chưa bật" else
            "Hằng ngày · " + String.format(java.util.Locale.getDefault(), "%02d:%02d", time / 60, time % 60)
        page.add(listItem("◷", "Giờ nhắc học", schedule) { editReminder(owner, time) }, 12)
    }
    private fun editReminder(owner: String, savedTime: Int?) {
        val now = Calendar.getInstance()
        val hour = savedTime?.div(60) ?: now.get(Calendar.HOUR_OF_DAY)
        val minute = savedTime?.rem(60) ?: now.get(Calendar.MINUTE)
        val picker = TimePickerDialog(this, { _, h, m ->
            reminders.save(owner, h * 60 + m)
            show(Screen.REMINDERS)
            if (android.os.Build.VERSION.SDK_INT >= 33 &&
                checkSelfPermission(android.Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
            ) {
                requestPermissions(arrayOf(android.Manifest.permission.POST_NOTIFICATIONS), 21)
            } else if (!getSystemService(NotificationManager::class.java).areNotificationsEnabled()) {
                Toast.makeText(this, "Hãy bật thông báo StudyAI Mentor trong Cài đặt Android.", Toast.LENGTH_LONG).show()
            }
        }, hour, minute, android.text.format.DateFormat.is24HourFormat(this))
        picker.setTitle("Giờ nhắc học hằng ngày")
        if (savedTime != null) picker.setButton(AlertDialog.BUTTON_NEUTRAL, "Tắt nhắc", android.content.DialogInterface.OnClickListener { _, _ ->
            reminders.remove(owner)
            show(Screen.REMINDERS)
        })
        picker.show()
    }
}

